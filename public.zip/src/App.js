import logo from './logo.svg';
import './App.css';
import Login from './component/Login';
import Dashboard from './component/Dashboard';

function App() {
  return (
    <div className="App">
     <Login></Login>
     <Dashboard></Dashboard>
     </div>
  );
}

export default App;
